jQuery(document).ready(function($){

		//Iniciando los contadores
		 $('.contador').countTo();

	
    

	





});